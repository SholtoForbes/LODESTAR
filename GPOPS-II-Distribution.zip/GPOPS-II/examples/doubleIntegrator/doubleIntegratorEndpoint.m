function output = doubleIntegratorEndpoint(input)

output.objective = input.phase.finaltime;
