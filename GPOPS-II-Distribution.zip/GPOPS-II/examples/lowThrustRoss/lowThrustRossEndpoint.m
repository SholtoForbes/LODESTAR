function output = lowThrustRossEndpoint(input)

output.objective = input.phase.finaltime;
