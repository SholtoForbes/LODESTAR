function output = seywaldMinimumClimbEndpoint(input)

tf = input.phase(1).finaltime;
output.objective = tf;
%----------------------------------%
% END: function minimumClimbCost.m %
%----------------------------------%
