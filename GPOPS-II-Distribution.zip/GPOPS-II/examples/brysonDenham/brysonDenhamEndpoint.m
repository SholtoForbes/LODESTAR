function output = BrysonDenhamEvents(input)

output.objective = input.phase.integral;
