%-----------------------------------------------------%
% Begin Function:  brysonMinimumTimeToClimbEndpoint.m %
%-----------------------------------------------------%
function output = brysonMinimumTimeToClimbEndpoint(input)

output.objective = input.phase(1).finaltime;;

%-----------------------------------------------------%
% End Function:  brysonMinimumTimeToClimbEndpoint.m   %
%-----------------------------------------------------%
