%-------------------------------------------%
% BEGIN: function brachistochroneEndpoint.m %
%-------------------------------------------%
function output = brachistochroneEndpoint(input)

output.objective = input.phase(1).finaltime;

%-------------------------------------------%
% END: function brachistochroneEndpoint.m   %
%-------------------------------------------%

